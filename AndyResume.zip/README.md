# new-resume
我的简历 &amp; 灵感来自Fernando Báez的设计 &amp; Zresume
